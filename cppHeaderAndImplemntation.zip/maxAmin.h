/*a header file
*contains two functions max and min
*these functions accept an array of size 10
*and the min function identifies the minimum value from the given array
*the max function identifies the maximum value from the given array*/

#include <iostream>
#include <iomanip>

int num = 10;

int min(int a[ 10 ]){
	//a = {5, 58, 47, 5, 7, 9, 10, 15, 8, 19};
	int mn = a[0];
	for(int i=0; i<num; i++){
			if(mn>a[i]){
				mn = a[i];
			}
		}
		return mn;
}

int max(int a[ 10 ]){
		//a = {5, 58, 47, 5, 7, 9, 10, 15, 8, 19};
		int mx=a[0];
		
		for(int i=0; i<num; i++){
			
			if(mx<a[i]){
				mx = a[i];
			}
		}
		return mx;
}
