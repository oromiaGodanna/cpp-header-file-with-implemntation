/*user program which uses the header file min and max*/
/*accepts an 10 integer numbers and passes them as an array
*two the two functions max and min defined in the header file
*accepts the result and print it as max and min*/

#include "maxAmin.h"
#include <iostream>
using namespace std;
#include <iomanip>


int a[10];
int main(){
	cout<<"Enter 10 values: " ;
	int num = 10;
	for(int i= 0; i<num; i++){
		cout<<"\nEnter value: " ;	
		cin>> a[i];
	}
	
	
	cout<<"The minimum value is : " <<min(a) <<endl;
	cout<<"The maximum value is : " <<max(a) <<endl;
	return 0;
}
